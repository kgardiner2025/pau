module.exports = {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Lexend', 'sans-serif']
      }
    },
  },
  plugins: [],
}
